// Simple auto-refresh every 60 seconds
setInterval(() => {
    console.log("Refreshing torrent list...");
    // Simulate refresh here
}, 60000);